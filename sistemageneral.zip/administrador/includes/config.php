<?php

  define( 'DB_HOST', 'localhost' );       // Host de la BD
  define( 'DB_USER', 'root' );            // Usuario de la BD
  define( 'DB_PASS', '' );          // Password de la BD
  define( 'DB_NAME', 'probar_antes_server' ); // Nombre de la BD

?>