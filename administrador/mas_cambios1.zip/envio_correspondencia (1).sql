CREATE TABLE `envio_correspondencia` (
  `id` int(11) NOT NULL,
  `folio` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fecha_emision` date NOT NULL,
  `asunto` varchar(300) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `medio_envio` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `se_turna_a_area` varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fecha_en_que_se_turna` date NOT NULL,
  `fecha_espera_respuesta` date NOT NULL,
  `tipo_tramite` varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `oficio_enviado` varchar(250) NOT NULL,
  `observaciones` varchar(350) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `accion_realizada` varchar(300) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `oficio_respuesta` varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `quien_realizo` varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `area_creacion` varchar(250) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `envio_correspondencia`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `envio_correspondencia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;
