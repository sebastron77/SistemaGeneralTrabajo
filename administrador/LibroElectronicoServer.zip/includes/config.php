<?php

  define( 'DB_HOST', 'localhost' );       // Host de la BD
  define( 'DB_USER', 'root' );            // Usuario de la BD
  define( 'DB_PASS', '' );          // Password de la BD
  define( 'DB_NAME', 'libro_electronico2' ); // Nombre de la BD

?>