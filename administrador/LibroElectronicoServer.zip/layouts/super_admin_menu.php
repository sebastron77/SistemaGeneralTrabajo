<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Panel de control</span>
    </a>
  </li>
  <li style="margin-bottom: 7px;">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-file"></i>
      <span>Solicitudes</span>
    </a>
    <ul class="nav submenu">
      <li><a href="solicitudes.php">Ver solicitudes</a> </li>
      <!-- <li><a href="quejas.php">Seguimiento de Solicitudes</a> </li> -->
    </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle" style="left: 18px; top: 2px;">
      <svg style="width:20px; height:20px;" viewBox="0 0 22 22">
        <path fill="currentColor" d="M20,17A2,2 0 0,0 22,15V4A2,2 0 0,0 20,2H9.46C9.81,2.61 10,3.3 10,4H20V15H11V17M15,7V9H9V22H7V16H5V22H3V14H1.5V9A2,2 0 0,1 3.5,7H15M8,4A2,2 0 0,1 6,6A2,2 0 0,1 4,4A2,2 0 0,1 6,2A2,2 0 0,1 8,4Z" />
      </svg>
      <span style="position: absolute; top: 50%; left: 50%; margin:-11px 0 0 -85px;">Capacitaciones</span>
    </a>
    <ul class="nav submenu">
      <li><a href="#">MOOC's</a> </li>
      <li><a target="_blank" href="https://virtual.cedhmichoacan.org/">Aula Virtual</a> </li>
      <li><a href="#">Registro de Constancias</a> </li>
    </ul>
  </li>
  <li style="margin-top: 5px;">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-book"></i>
      <span>Áreas y Cargos</span>
    </a>
    <ul class="nav submenu">
      <li><a href="areas.php">Administrar áreas</a> </li>
      <li><a href="cargos.php">Administrar cargos</a> </li>
    </ul>
  </li>
  <li style="margin-top:8px;">
    <a href="#" class="submenu-toggle" style="left: 18px; top:2px">
      <svg style="width:22px;height:22px" viewBox="0 0 24 24">
        <path fill="currentColor" d="M12,19.2C9.5,19.2 7.29,17.92 6,16C6.03,14 10,12.9 12,12.9C14,12.9 17.97,14 18,16C16.71,17.92 14.5,19.2 12,19.2M12,5A3,3 0 0,1 15,8A3,3 0 0,1 12,11A3,3 0 0,1 9,8A3,3 0 0,1 12,5M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z" />
      </svg>
      <span style="position: absolute; top: 50%; left: 50%; margin:-11px 0 0 -85px;">Gestión de Usuarios</span>
    </a>
    <ul class="nav submenu">
      <li><a href="group.php">Administrar grupos de usuarios</a> </li>
      <li><a href="users.php">Administrar cuentas de usuarios</a> </li>
    </ul>
  </li>
  <li style="margin-top: 5px;">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Gestión de trabajadores</span>
    </a>
    <ul class="nav submenu">
      <li><a href="detalles_usuario.php">Administrar información</a> </li>
    </ul>
  </li>
  <!-- <li style="margin-top: 5px;">
    <a href="folios.php" style="left: 18px; top:2px">
      <svg style="width:22px;height:22px" viewBox="0 0 24 24">
        <path fill="currentColor" d="M4,4H20A2,2 0 0,1 22,6V18A2,2 0 0,1 20,20H4A2,2 0 0,1 2,18V6A2,2 0 0,1 4,4M4,6V18H11V6H4M20,18V6H18.76C19,6.54 18.95,7.07 18.95,7.13C18.88,7.8 18.41,8.5 18.24,8.75L15.91,11.3L19.23,11.28L19.24,12.5L14.04,12.47L14,11.47C14,11.47 17.05,8.24 17.2,7.95C17.34,7.67 17.91,6 16.5,6C15.27,6.05 15.41,7.3 15.41,7.3L13.87,7.31C13.87,7.31 13.88,6.65 14.25,6H13V18H15.58L15.57,17.14L16.54,17.13C16.54,17.13 17.45,16.97 17.46,16.08C17.5,15.08 16.65,15.08 16.5,15.08C16.37,15.08 15.43,15.13 15.43,15.95H13.91C13.91,15.95 13.95,13.89 16.5,13.89C19.1,13.89 18.96,15.91 18.96,15.91C18.96,15.91 19,17.16 17.85,17.63L18.37,18H20M8.92,16H7.42V10.2L5.62,10.76V9.53L8.76,8.41H8.92V16Z" />
      </svg>
      <span style="position: absolute; top: 50%; left: 50%; margin:-11px 0 0 -85px;">Números de Folio Usados</span>
    </a>
  </li> -->
  <li style="margin-top: 5px;">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
      <span>Estadísticas</span>
    </a>
    <ul class="nav submenu">
      <li><a href="#">Medida Cautelar</a></li>
      <li><a href="#">Orientaciones</a></li>
      <li><a href="#">Canalizaciones</a></li>
      <li><a href="#">Gestiones</a></li>
      <li><a href="#">Solicitud de información</a></li>
      <li><a href="#">Capacitaciones</a></li>
      <li><a href="#">Quejas</a></li>
    </ul>
  </li>
</ul>